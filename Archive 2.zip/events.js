// Continuation of events.js

const eventLocation = encodeURIComponent(event.location || 'University of Maryland');
const startDate = new Date(event.datetime);
const endDate = new Date(startDate);
endDate.setHours(endDate.getHours() + 2); // Default 2-hour event

const startIso = startDate.toISOString().replace(/-|:|\.\d+/g, '');
const endIso = endDate.toISOString().replace(/-|:|\.\d+/g, '');

const calendarUrl = `https://www.google.com/calendar/render?action=TEMPLATE&text=${eventName}&details=${eventDetails}&location=${eventLocation}&dates=${startIso}/${endIso}`;

window.open(calendarUrl, '_blank');

// Share event button
const shareEventBtn = document.getElementById('shareEventBtn');
shareEventBtn.onclick = function() {
if (navigator.share) {
  navigator.share({
    title: event.name,
    text: `Check out this event: ${event.name} on ${formatDate(event.datetime)}`,
    url: window.location.href
  })
  .catch(err => {
    console.error('Share failed:', err);
  });
} else {
  // Fallback - copy to clipboard
  const shareText = `Check out this event: ${event.name} on ${formatDate(event.datetime)} at ${event.location || 'UMD'}`;
  navigator.clipboard.writeText(shareText)
    .then(() => {
      alert('Event info copied to clipboard!');
    })
    .catch(err => {
      console.error('Could not copy text:', err);
    });
}
};


// Build and display calendar view
function displayCalendarView(events) {
// Show calendar container, hide events container
document.getElementById('eventsContainer').classList.add('hidden');
document.getElementById('calendarView').classList.remove('hidden');

// Current date for calendar
const calendar = {
currentDate: new Date(),
year: new Date().getFullYear(),
month: new Date().getMonth()
};

// Initial calendar build
buildCalendar(calendar, events);

// Setup month navigation
document.getElementById('prevMonth').onclick = function() {
calendar.month--;
if (calendar.month < 0) {
  calendar.month = 11;
  calendar.year--;
}
buildCalendar(calendar, events);
};

document.getElementById('nextMonth').onclick = function() {
calendar.month++;
if (calendar.month > 11) {
  calendar.month = 0;
  calendar.year++;
}
buildCalendar(calendar, events);
};
}

// Build calendar with events
function buildCalendar(calendar, events) {
// Update header
const monthNames = ["January", "February", "March", "April", "May", "June",
"July", "August", "September", "October", "November", "December"];
document.getElementById('currentMonth').textContent = `${monthNames[calendar.month]} ${calendar.year}`;

// Get the first day of the month and the number of days
const firstDay = new Date(calendar.year, calendar.month, 1).getDay();
const daysInMonth = new Date(calendar.year, calendar.month + 1, 0).getDate();

// Get today's date for highlighting
const today = new Date();
const isCurrentMonth = today.getMonth() === calendar.month && today.getFullYear() === calendar.year;

// Get calendar grid
const calendarGrid = document.querySelector('.calendar-grid');

// Clear existing calendar days (excluding headers)
const headers = calendarGrid.querySelectorAll('.calendar-day-header');
calendarGrid.innerHTML = '';
headers.forEach(header => calendarGrid.appendChild(header));

// Create blank spaces for days before the 1st
for (let i = 0; i < firstDay; i++) {
const blankDay = document.createElement('div');
blankDay.className = 'calendar-day empty';
calendarGrid.appendChild(blankDay);
}

// Create day cells
for (let day = 1; day <= daysInMonth; day++) {
const dayCell = document.createElement('div');
dayCell.className = 'calendar-day';

// Check if this day is today
if (isCurrentMonth && day === today.getDate()) {
  dayCell.classList.add('today');
}

// Day number
const dayNumber = document.createElement('div');
dayNumber.className = 'day-number';
dayNumber.textContent = day;
dayCell.appendChild(dayNumber);

// Find events for this day
const dayDate = new Date(calendar.year, calendar.month, day);
const dayEvents = events.filter(event => {
  const eventDate = new Date(event.datetime);
  return eventDate.getDate() === day && 
         eventDate.getMonth() === calendar.month && 
         eventDate.getFullYear() === calendar.year;
});

// Add events to the day cell
if (dayEvents.length > 0) {
  dayCell.classList.add('has-events');
  
  const eventsContainer = document.createElement('div');
  eventsContainer.className = 'day-events';
  
  // Sort events by time
  dayEvents.sort((a, b) => new Date(a.datetime) - new Date(b.datetime));
  
  // Add up to 3 events, with a "+X more" indicator if needed
  const displayLimit = 3;
  const displayEvents = dayEvents.slice(0, displayLimit);
  
  displayEvents.forEach(event => {
    const eventDiv = document.createElement('div');
    eventDiv.className = 'calendar-event';
    eventDiv.dataset.eventId = event.id;
    
    eventDiv.innerHTML = `
      <span class="event-time">${formatTime(event.datetime)}</span>
      <span class="event-title">${event.name}</span>
    `;
    
    eventDiv.addEventListener('click', () => {
      showEventDetails(event.id);
    });
    
    eventsContainer.appendChild(eventDiv);
  });
  
  // Add "more" indicator if needed
  if (dayEvents.length > displayLimit) {
    const moreDiv = document.createElement('div');
    moreDiv.className = 'more-events';
    moreDiv.textContent = `+ ${dayEvents.length - displayLimit} more`;
    
    moreDiv.addEventListener('click', () => {
      // Filter to show just this day's events
      document.getElementById('dateFilter').value = 'custom';
      document.getElementById('calendarView').classList.add('hidden');
      document.getElementById('eventsContainer').classList.remove('hidden');
      
      // Switch to list view for better display
      setViewMode('list');
      
      // Apply custom date filter for this day
      const filteredEvents = events.filter(event => {
        const eventDate = new Date(event.datetime);
        return eventDate.getDate() === day && 
              eventDate.getMonth() === calendar.month && 
              eventDate.getFullYear() === calendar.year;
      });
      
      displayEventsList(filteredEvents);
    });
    
    eventsContainer.appendChild(moreDiv);
  }
  
  dayCell.appendChild(eventsContainer);
}

calendarGrid.appendChild(dayCell);
}
}

// Set active view mode
function setViewMode(mode) {
// Update active button
document.querySelectorAll('.view-toggle button').forEach(btn => {
btn.classList.remove('active');
});

// Reset containers
document.getElementById('eventsContainer').classList.remove('hidden');
document.getElementById('calendarView').classList.add('hidden');

// Apply view mode
switch (mode) {
case 'grid':
  document.getElementById('gridViewBtn').classList.add('active');
  document.getElementById('eventsContainer').className = 'events-grid';
  break;
case 'list':
  document.getElementById('listViewBtn').classList.add('active');
  document.getElementById('eventsContainer').className = 'events-list';
  break;
case 'calendar':
  document.getElementById('calendarViewBtn').classList.add('active');
  // Calendar view handled separately
  break;
}
}

// Apply filters and update display
function applyFilters() {
const searchTerm = document.getElementById('searchInput').value;
const category = document.getElementById('categoryFilter').value;
const location = document.getElementById('locationFilter').value;
const dateFilter = document.getElementById('dateFilter').value;

const allEvents = getAllEvents();
const filteredEvents = filterEvents(allEvents, searchTerm, category, location, dateFilter);

// Determine active view
const activeView = document.querySelector('.view-toggle button.active').id;

if (activeView === 'gridViewBtn') {
document.getElementById('eventsContainer').className = 'events-grid';
displayEventsGrid(filteredEvents);
} else if (activeView === 'listViewBtn') {
displayEventsList(filteredEvents);
} else if (activeView === 'calendarViewBtn') {
displayCalendarView(filteredEvents);
}
}

// Initialize the page
document.addEventListener('DOMContentLoaded', () => {
// Initial events display
const allEvents = getAllEvents();
displayEventsGrid(allEvents);

// Set up search and filters
document.getElementById('searchInput').addEventListener('input', applyFilters);
document.getElementById('categoryFilter').addEventListener('change', applyFilters);
document.getElementById('locationFilter').addEventListener('change', applyFilters);
document.getElementById('dateFilter').addEventListener('change', applyFilters);

// Set up view toggles
document.getElementById('gridViewBtn').addEventListener('click', () => {
setViewMode('grid');
applyFilters();
});

document.getElementById('listViewBtn').addEventListener('click', () => {
setViewMode('list');
applyFilters();
});

document.getElementById('calendarViewBtn').addEventListener('click', () => {
setViewMode('calendar');
applyFilters();
});
});