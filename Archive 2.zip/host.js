// Host page JavaScript
// Format date for display
function formatDate(dateString) {
    const options = { 
      weekday: 'long', 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    };
    return new Date(dateString).toLocaleDateString(undefined, options);
  }
  
  // Generate a unique ID for events
  function generateEventId() {
    return Date.now().toString(36) + Math.random().toString(36).substring(2, 5);
  }
  
  // Delete an event
  function deleteEvent(eventId) {
    if (confirm("Are you sure you want to delete this event?")) {
      const events = JSON.parse(localStorage.getItem("events") || "[]");
      const updatedEvents = events.filter(e => e.id !== eventId);
      localStorage.setItem("events", JSON.stringify(updatedEvents));
      displayOrganizerEvents(); // Refresh the display
    }
  }
  
  // Display all events for the current organizer
  function displayOrganizerEvents() {
    const organizerInput = document.getElementById("organizer");
    const organizer = organizerInput ? organizerInput.value : "";
    
    // If no organizer name entered yet, don't show anything
    if (!organizer) {
      document.getElementById("noEvents").classList.remove("hidden");
      return;
    }
    
    const allEvents = JSON.parse(localStorage.getItem("events") || "[]");
    const organizerEvents = allEvents.filter(e => e.organizer === organizer);
    const eventsContainer = document.getElementById("organizerEvents");
    
    // Clear existing content
    eventsContainer.innerHTML = "";
    
    if (organizerEvents.length === 0) {
      document.getElementById("noEvents").classList.remove("hidden");
      eventsContainer.appendChild(document.getElementById("noEvents"));
      return;
    }
    
    document.getElementById("noEvents").classList.add("hidden");
    
    // Sort events by date (newest first)
    organizerEvents.sort((a, b) => new Date(b.datetime) - new Date(a.datetime));
    
    // Create event cards
    organizerEvents.forEach(event => {
      const eventCard = document.createElement("div");
      eventCard.className = "event-card";
      eventCard.innerHTML = `
        <h3>${event.name}</h3>
        <p class="event-date">${formatDate(event.datetime)}</p>
        <p class="event-location"><strong>Location:</strong> ${event.location || 'Not specified'}</p>
        <p class="event-category"><strong>Category:</strong> ${event.category || 'Not categorized'}</p>
        <p class="event-description">${event.description}</p>
        <div class="event-actions">
          <button class="edit-button" data-id="${event.id}">Edit</button>
          <button class="delete-button" data-id="${event.id}">Delete</button>
        </div>
      `;
      eventsContainer.appendChild(eventCard);
    });
    
    // Add event listeners to buttons
    document.querySelectorAll(".delete-button").forEach(button => {
      button.addEventListener("click", () => deleteEvent(button.dataset.id));
    });
    
    document.querySelectorAll(".edit-button").forEach(button => {
      button.addEventListener("click", () => editEvent(button.dataset.id));
    });
  }
  
  // Populate the form for editing
  function editEvent(eventId) {
    const events = JSON.parse(localStorage.getItem("events") || "[]");
    const event = events.find(e => e.id === eventId);
    
    if (event) {
      // Fill the form fields
      document.getElementById("name").value = event.name;
      document.getElementById("organizer").value = event.organizer;
      document.getElementById("datetime").value = event.datetime.substring(0, 16); // Format for datetime-local
      if (event.location) document.getElementById("location").value = event.location;
      if (event.category) document.getElementById("category").value = event.category;
      document.getElementById("description").value = event.description;
      if (event.contactEmail) document.getElementById("contactEmail").value = event.contactEmail;
      if (event.contactPhone) document.getElementById("contactPhone").value = event.contactPhone;
      if (event.registrationLink) document.getElementById("registrationLink").value = event.registrationLink;
      
      // Change form behavior to update instead of create
      const form = document.getElementById("hostEventForm");
      form.dataset.editing = eventId;
      
      // Change button text
      const submitButton = form.querySelector('button[type="submit"]');
      submitButton.textContent = "Update Event";
      
      // Scroll to form
      form.scrollIntoView({ behavior: 'smooth' });
    }
  }
  
  // Initialize the page
  document.addEventListener("DOMContentLoaded", () => {
    // Set up form submission
    const form = document.getElementById("hostEventForm");
    if (form) {
      form.addEventListener("submit", (e) => {
        e.preventDefault();
        
        // Collect form data
        const eventData = {
          name: document.getElementById("name").value,
          organizer: document.getElementById("organizer").value,
          datetime: document.getElementById("datetime").value,
          location: document.getElementById("location").value,
          category: document.getElementById("category").value,
          description: document.getElementById("description").value,
          contactEmail: document.getElementById("contactEmail").value,
          contactPhone: document.getElementById("contactPhone").value || null,
          registrationLink: document.getElementById("registrationLink").value || null
        };
        
        // Check if we're editing an existing event
        if (form.dataset.editing) {
          // Update existing event
          const events = JSON.parse(localStorage.getItem("events") || "[]");
          const eventIndex = events.findIndex(e => e.id === form.dataset.editing);
          
          if (eventIndex !== -1) {
            // Preserve the ID and creation timestamp
            eventData.id = form.dataset.editing;
            eventData.createdAt = events[eventIndex].createdAt;
            eventData.updatedAt = new Date().toISOString();
            
            events[eventIndex] = eventData;
            localStorage.setItem("events", JSON.stringify(events));
            
            // Reset form for new events
            form.reset();
            delete form.dataset.editing;
            form.querySelector('button[type="submit"]').textContent = "Create Event";
            
            // Show updated events
            displayOrganizerEvents();
            
            alert("Event updated successfully!");
            return;
          }
        }
        
        // Create new event
        const addToCalendar = document.getElementById("addToCalendar").checked;
        
        if (addToCalendar) {
          // Save to local storage and redirect for Google Calendar integration
          addEventToCalendar(eventData);
        } else {
          // Just save to local storage
          eventData.id = generateEventId();
          eventData.createdAt = new Date().toISOString();
          
          const existing = JSON.parse(localStorage.getItem("events") || "[]");
          existing.push(eventData);
          localStorage.setItem("events", JSON.stringify(existing));
          
          form.reset();
          displayOrganizerEvents();
          alert("Event created successfully!");
        }
      });
    }
    
    // Set up real-time filtering of events when organizer name changes
    const organizerInput = document.getElementById("organizer");
    if (organizerInput) {
      organizerInput.addEventListener("input", displayOrganizerEvents);
    }
    
    // Initial display of events
    displayOrganizerEvents();
  });