const CLIENT_ID = '650848625894-limvhnaauvjgc8sogobhm0tenhg2d0cu.apps.googleusercontent.com';
const API_KEY = 'AIzaSyAeYk8Khbm_bDftl9xDsJef8uRLTE5xlk0';
const DISCOVERY_DOCS = ["https://www.googleapis.com/discovery/v1/apis/calendar/v3/rest"];
const SCOPES = "https://www.googleapis.com/auth/calendar.events";

// IMPORTANT: This must match exactly what's registered in Google Cloud Console
// Replace this with your actual redirect URI that's registered in Google Cloud Console
const REDIRECT_URI = "http://localhost:8080/oauth2callback.html";

// Generate a random state value for CSRF protection
function generateState() {
  return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
}

// Store state in localStorage
function saveState() {
  const state = generateState();
  localStorage.setItem('oauth_state', state);
  return state;
}

function gapiInit() {
  gapi.load("client:auth2", () => {
    gapi.client.init({
      apiKey: API_KEY,
      clientId: CLIENT_ID,
      discoveryDocs: DISCOVERY_DOCS,
      scope: SCOPES
    });
  });
}

function addEventToCalendar(eventData) {
  // Generate and save a state value
  const state = saveState();
  
  // Use the fixed redirect URI that matches your Google Cloud Console setting
  const redirectUri = encodeURIComponent(REDIRECT_URI);
  const authUrl = `https://accounts.google.com/o/oauth2/v2/auth?` +
    `client_id=${CLIENT_ID}` +
    `&redirect_uri=${redirectUri}` +
    `&response_type=code` +
    `&scope=${encodeURIComponent(SCOPES)}` +
    `&state=${state}` +
    `&access_type=offline` +
    `&prompt=consent`;
  
  // Store event data to retrieve after auth
  localStorage.setItem('pendingEvent', JSON.stringify(eventData));
  
  // Redirect to Google's auth server
  window.location.href = authUrl;
}