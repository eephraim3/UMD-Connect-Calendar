const CLIENT_ID = '650848625894-limvhnaauvjgc8sogobhm0tenhg2d0cu.apps.googleusercontent.com';
const API_KEY = 'AIzaSyAeYk8Khbm_bDftl9xDsJef8uRLTE5xlk0';
const DISCOVERY_DOCS = ["https://www.googleapis.com/discovery/v1/apis/calendar/v3/rest"];
const SCOPES = "https://www.googleapis.com/auth/calendar.events";

function gapiInit() {
  gapi.load("client:auth2", () => {
    gapi.client.init({
      apiKey: API_KEY,
      clientId: CLIENT_ID,
      discoveryDocs: DISCOVERY_DOCS,
      scope: SCOPES
    });
  });
}

function addEventToCalendar(eventData) {
  gapi.auth2.getAuthInstance().signIn().then(() => {
    const isoTime = new Date(eventData.datetime).toISOString();
    const event = {
      summary: eventData.name,
      description: eventData.description,
      start: { dateTime: isoTime },
      end: { dateTime: new Date(new Date(eventData.datetime).getTime() + 60 * 60 * 1000).toISOString() },
    };

    gapi.client.calendar.events.insert({
      calendarId: 'primary',
      resource: event
    }).then(() => {
      saveToLocal(eventData);
      window.location.href = `feed.html?organizer=${encodeURIComponent(eventData.organizer)}`;
    });
  });
}

function saveToLocal(eventData) {
  const existing = JSON.parse(localStorage.getItem("events") || "[]");
  existing.push(eventData);
  localStorage.setItem("events", JSON.stringify(existing));
}

document.addEventListener("DOMContentLoaded", () => {
  gapiInit();

  const form = document.getElementById("eventForm");
  form?.addEventListener("submit", (e) => {
    e.preventDefault();
    const eventData = {
      name: document.getElementById("name").value,
      organizer: document.getElementById("organizer").value,
      datetime: document.getElementById("datetime").value,
      description: document.getElementById("description").value
    };
    addEventToCalendar(eventData);
  });
});